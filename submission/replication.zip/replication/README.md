# Replication package

## Data

Processed data used by the analyses in the paper are available in the `data/` folder in RDS format.

## Code

### System requirements

- Windows, MacOS, or Linux
- R installation
- C++ compiler

### Installation

- Install R version 4 or later
- Install the following R packages' current versions from CRAN:
    - `rlang`
    - `tidyverse`
    - `sf`
    - `redist`
    - `scales`
    - `patchwork`
    - `wacolors`
    - `here`
    - `Rcpp`
    - `tigris`
    - `ragg`
    - `png`
    - `rmapshaper`
    - `ggredist`
    - `alarmdata`

The installation should take under an hour within an hour on a typical personal computer.

### Running the analysis

All R and Stan code is available in the `R/` folder.
To replicate the figures and analyses in the paper, run the scripts in `R/` in order:

```r
lapply(sort(Sys.glob("R/*.R")), source)
```

The analysis should run within an hour on a typical personal computer.
